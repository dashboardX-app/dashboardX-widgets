<script setup lang="ts">
import { ref } from "vue";
import Icon from "./Icon.vue";
import { redirectToAuthCodeFlow, getAccessToken } from "./spotifyAuth";

const clientId = "insert client id";
const params = new URLSearchParams(window.location.search);
const code = params.get("code")!;

/* Data */
const albumArtURL = ref("/music-placeholder.png");
const track = ref("Nothing playing");
const artist = ref("Unknown Artist");

const trackProgress = ref(0);
const totalDuration = ref(20);

const isPlaying = ref(true);

const repeatMode = ref(0);
/*const isShuffled = ref(false);*/
const isLiked = ref(true);

const accessToken = ref("");

const secDisplay = (seconds: number) => {
  let min = Math.floor(seconds / 60);
  let sec = Math.floor(seconds % 60);
  return `${min}:${sec < 10 ? "0" + sec : sec}`;
};

const getTokenAndData = async () => {
  accessToken.value = await getAccessToken(clientId, code);
  getPlayerData();
};

const getPlayerData = async () => {
  const result = await fetch("https://api.spotify.com/v1/me/player", {
    method: "GET",
    headers: { Authorization: `Bearer ${accessToken.value}` },
  });

  const json = await result.json();
  console.log(json);
  isPlaying.value = json.is_playing;
  totalDuration.value = Math.floor(json.item.duration_ms / 1000);
  trackProgress.value =
    Math.floor(json.progress_ms / 1000) / totalDuration.value;
  repeatMode.value =
    json.repeat_state == "off" ? 0 : json.repeat_state == "context" ? 1 : 2;
  track.value = json.item.name;
  artist.value = json.item.artists[0].name;
  albumArtURL.value = json.item.album.images[0].url;
};

const togglePlay = async () => {
  console.log(accessToken.value);

  /*const result = await fetch(`https://api.spotify.com/v1/me/player/pause`, {
    method: "PUT",
    headers: { Authorization: `Bearer ${accessToken.value}` },
  });*/

  getPlayerData();
};

if (!code) {
  redirectToAuthCodeFlow(clientId);
} else {
  getTokenAndData();
}

setInterval(() => {
  if (isPlaying.value)
    if (trackProgress.value < 1) {
      trackProgress.value += 1 / totalDuration.value;
    } else {
      trackProgress.value = 0;
      getPlayerData();
    }
}, 1000);
</script>

<template>
  <div class="player">
    <img class="albumArt" :src="albumArtURL" />
    <div class="playerData">
      <div class="trackName text-md font-semibold">{{ track }}</div>
      <div class="artistName text-sm font-medium">{{ artist }}</div>

      <div class="progress">
        <div class="bar" :style="`width: ${trackProgress * 100}%`"></div>

        <div
          class="time w-full text-xs flex justify-between absolute top-1.5 pointer-events-none"
        >
          <div>{{ secDisplay(trackProgress * totalDuration) }}</div>
          <div>{{ secDisplay(totalDuration) }}</div>
        </div>
      </div>
      <div class="controls mt-2 flex gap-0.5 justify-center items-center">
        <Icon class="showOnHover text-lg px-0.5" name="bi-shuffle" />
        <Icon class="text-2xl" name="bi-skip-start-fill" />
        <Icon
          class="text-3xl"
          :name="isPlaying ? 'bi-pause-fill' : 'bi-play-fill'"
          @click="togglePlay()"
        />
        <Icon class="text-2xl" name="bi-skip-end-fill" />
        <Icon
          class="showOnHover text-lg px-0.5"
          :name="repeatMode == 2 ? 'bi-repeat-1' : 'bi-repeat'"
        />
      </div>
    </div>
    <div class="likebtn absolute top-4 right-4 leading-none">
      <Icon
        :class="isLiked ? 'text-rose-500' : ''"
        :name="isLiked ? 'bi-heart-fill' : 'bi-heart'"
      />
    </div>
    <div
      class="absolute -bottom-8 left-0 right-0 text-center text-sm hover:underline cursor-pointer select-none"
      onclick="window.location.href = `http://localhost:1420`"
    >
      Connect Account
    </div>
  </div>
</template>

<style>
@import url("https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css");
.player {
  @apply bg-zinc-100 dark:bg-slate-900 bg-opacity-60 dark:bg-opacity-60 backdrop-blur-xl text-black dark:text-white h-36 w-96 p-4 flex gap-4 rounded-2xl relative;
}
.albumArt {
  @apply rounded-lg aspect-square h-28;
}
.playerData {
  @apply flex flex-col justify-center items-center text-center w-full;
}
.progress {
  @apply mt-2 w-full h-1 bg-zinc-200 dark:bg-white bg-opacity-30 dark:bg-opacity-30 rounded-md relative;
}
.bar {
  @apply h-1 bg-zinc-800 dark:bg-zinc-100 rounded-md;
  transition: width 1s linear;
}
.showOnHover {
  @apply opacity-0 pointer-events-none transition-all;
}
.controls * {
  @apply leading-none;
}
.controls:hover .showOnHover {
  @apply opacity-100 pointer-events-auto;
}
</style>
