<script setup lang="ts">
const props = defineProps(["name"])
</script>

<template>
  <i :class="`bi ${props.name}`"></i>
</template>